import json
import os
import urllib.request

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

def lambda_handler(event, context):
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'OPTIONS,POST'
    }

    # Preflight OPTIONS 요청에 대해 즉시 200 OK 응답 반환
    http_method = event.get('requestContext', {}).get('http', {}).get('method') or event.get('httpMethod')
    if http_method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }

    try:
        body = json.loads(event.get('body', '{}'))
        user_id = body.get('userId')
        ingredients = body.get('ingredients', [])
        user_message = body.get('message', '이 재료들로 뭐 만들어 먹을까?')

        if not user_id:
            return {'statusCode': 400, 'headers': headers, 'body': json.dumps({'error': 'userId가 필요합니다.'}, ensure_ascii=False)}

        system_prompt = f"""
        너는 냉장고 파먹기 전문 프로 AI 셰프야. 유저의 냉장고 재료와 요청사항을 바탕으로 현실적이고 맛있는 요리를 추천해줘.
        
        [현재 유저의 냉장고 재료 목록]
        {json.dumps(ingredients, ensure_ascii=False)}

        [규칙]
        1. 유저가 요리 관련 고민을 말하면 친절하게 요리를 추천해줘.
        2. 재료 목록에서 **실제로 그 요리에 어울리는 핵심 재료만 2~4개 정도 골라서** 레시피를 구성해줘. (목록에 있다고 해서 아무 재료나 억지로 다 갖다 붙이지 마세요.)
        3. **[계량 및 비율 규칙]** 각 재료의 사용량은 실제 요리할 때 들어가는 **현실적인 적정량(예: 다진 마늘 1스푼, 대파 1/2대, 고춧가루 1큰술 등)**으로만 정확히 표기해줘. 절대 재료를 과도하게 많이 쓰거나 비율이 어긋나게 레시피를 작성하지 마세요.
        """

        payload = {
            "model": "gpt-4o-mini",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            "max_tokens": 800,
            "temperature": 0.7
        }

        req = urllib.request.Request(
            "https://api.openai.com/v1/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {OPENAI_API_KEY}"
            },
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=9) as res:
            res_data = json.loads(res.read().decode("utf-8"))
            ai_reply = res_data['choices'][0]['message']['content'].strip()

        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({'reply': ai_reply}, ensure_ascii=False)
        }

    except Exception as e:
        print(f"Chatbot Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': str(e)}, ensure_ascii=False)
        }