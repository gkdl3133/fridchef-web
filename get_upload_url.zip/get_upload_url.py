import json
import boto3
import os
import uuid

s3 = boto3.client('s3')
BUCKET_NAME = os.environ.get('BUCKET_NAME', 'my-refrigerator-receipts-nonong')

def lambda_handler(event, context):
    try:
        query_params = event.get('queryStringParameters') or {}
        user_id = query_params.get('userId', 'anonymous')
        
        receipt_id = str(uuid.uuid4())
        s3_key = f"uploads/{user_id}/{receipt_id}.jpg"

        upload_url = s3.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': BUCKET_NAME,
                'Key': s3_key,
                'ContentType': 'image/jpeg',
                'Metadata': {
                    'userid': user_id,
                    'receiptid': receipt_id
                }
            },
            ExpiresIn=3600
        )

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': True
            },
            'body': json.dumps({
                'uploadUrl': upload_url,
                'receiptId': receipt_id,
                's3Key': s3_key
            })
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': str(e)})
        }