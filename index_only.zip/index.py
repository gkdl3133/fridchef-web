import json
import os
import boto3
from openai import OpenAI

# DynamoDB 및 S3 클라이언트 생성
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')
table = dynamodb.Table('Receipts')

# OpenAI 클라이언트 (환경변수에서 API 키를 가져옵니다)
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

def handler(event, context):
    for record in event.get('Records', []):
        bucket_name = record['s3']['bucket']['name']
        object_key = record['s3']['object']['key']
        receipt_id = object_key.split('.')[0]
        
        print(f"Processing image for AI analysis: {bucket_name}/{object_key}")
        
        try:
            # 1. S3에서 이미지 파일의 Presigned URL 생성 (OpenAI가 접근 가능하도록)
            image_url = s3_client.generate_presigned_url(
                'get_object',
                Params={'Bucket': bucket_name, 'Key': object_key},
                ExpiresIn=300
            )
            
            # 2. OpenAI Vision API 호출 (영수증 분석 및 JSON 구조화 요청)
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": "이 영수증/식재료 이미지에서 구매한 식재료 목록을 추출해줘. 각 식재료별로 name(이름), quantity(수량/숫자만), category(채소/육류/수산물/유제품/조미료/기타 중 하나) 정보를 포함한 JSON 배열 형태로만 응답해줘. 예시: [{\"name\": \"대파\", \"quantity\": 1, \"category\": \"채소\"}]"
                            },
                            {
                                "type": "image_url",
                                "image_url": {"url": image_url}
                            }
                        ]
                    }
                ],
                max_tokens=500
            )
            
            # 3. AI 분석 결과 텍스트 추출 및 JSON 파싱
            ai_output = response.choices[0].message.content
            if "```json" in ai_output:
                ai_output = ai_output.split("```json")[1].split("```")[0].strip()
            elif "```" in ai_output:
                ai_output = ai_output.split("```")[1].split("```")[0].strip()
                
            parsed_items = json.loads(ai_output)
            
            # 4. DynamoDB에 최종 분석된 식재료 데이터 저장 및 상태 변경 (COMPLETED)
            table.put_item(
                Item={
                    'receiptId': receipt_id,
                    'status': 'COMPLETED',
                    's3Path': f"s3://{bucket_name}/{object_key}",
                    'items': parsed_items
                }
            )
            print(f"Successfully processed receipt: {receipt_id}")

        except Exception as e:
            print(f"Error processing image: {str(e)}")
            table.put_item(
                Item={
                    'receiptId': receipt_id,
                    'status': 'FAILED',
                    'error': str(e)
                }
            )

    return {'statusCode': 200, 'body': json.dumps('SUCCESS')}