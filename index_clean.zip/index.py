import json
import os
import urllib.request
import base64
import boto3

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Receipts')

OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')

def handler(event, context):
    receipt_id = None
    try:
        # S3 이벤트 분석
        record = event['Records'][0]['s3']
        bucket_name = record['bucket']['name']
        object_key = urllib.parse.unquote_plus(record['object']['key'])
        
        receipt_id = object_key.split('.')[0]
        s3_path = f"s3://{bucket_name}/{object_key}"

        # DynamoDB 상태 업데이트 (PROCESSING)
        table.put_item(
            Item={
                'receiptId': receipt_id,
                's3Path': s3_path,
                'status': 'PROCESSING'
            }
        )

        # 1. S3에서 파일 직접 다운로드
        s3_response = s3.get_object(Bucket=bucket_name, Key=object_key)
        file_bytes = s3_response['Body'].read()
        
        # 이미지 파일 여부 체크 및 Base64 인코딩
        is_image = object_key.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))
        
        if is_image:
            base64_image = base64.b64encode(file_bytes).decode('utf-8')
            content_payload = [
                {"type": "text", "text": "Extract items from this receipt. Return ONLY a JSON array of objects with keys: 'name' (string), 'quantity' (number), 'category' (string). Do not format as markdown, return raw JSON string."},
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{base64_image}"
                    }
                }
            ]
        else:
            # 텍스트/기타 파일 처리
            file_text = file_bytes.decode('utf-8', errors='ignore')
            content_payload = f"Extract items from this receipt text: {file_text}\nReturn ONLY a JSON array of objects with keys: 'name', 'quantity', 'category'."

        # 2. OpenAI API 호출
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {OPENAI_API_KEY}"
        }
        
        payload = {
            "model": "gpt-4o-mini",
            "messages": [
                {
                    "role": "user",
                    "content": content_payload
                }
            ],
            "max_tokens": 1000
        }

        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
        
        with urllib.request.urlopen(req) as response:
            res_body = json.loads(response.read().decode('utf-8'))
            ai_output = res_body['choices'][0]['message']['content']

        # Markdown backticks 제거 정돈
        clean_json = ai_output.replace("```json", "").replace("```", "").strip()

        # 3. DynamoDB에 COMPLETED 상태로 결과 저장
        table.update_item(
            Key={'receiptId': receipt_id},
            UpdateExpression="SET #s = :status, aiResult = :res",
            ExpressionAttributeNames={'#s': 'status'},
            ExpressionAttributeValues={
                ':status': 'COMPLETED',
                ':res': clean_json
            }
        )

        return {'statusCode': 200, 'body': 'Success'}

    except Exception as e:
        print(f"Error processing receipt: {str(e)}")
        if receipt_id:
            table.update_item(
                Key={'receiptId': receipt_id},
                UpdateExpression="SET #s = :status, errorLog = :err",
                ExpressionAttributeNames={'#s': 'status'},
                ExpressionAttributeValues={
                    ':status': 'FAILED',
                    ':err': str(e)
                }
            )
        raise e